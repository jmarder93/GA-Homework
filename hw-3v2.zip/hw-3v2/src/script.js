<!-- Logo: https://s3-us-west-2.amazonaws.com/s.cdpn.io/2522641/logo.png -->
 <!-- Heart icon: https://s3-us-west-2.amazonaws.com/s.cdpn.io/2522641/heart.png -->
 <!-- Chat icon: https://s3-us-west-2.amazonaws.com/s.cdpn.io/2522641/chat.png -->
 
<<< OLD CSS >>>

HTML
<p>Make it look like this:</p>
    <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/2522641/airbnb-solution-image.jpg" alt="solution" style="width:1200px;" />
  </body>


.fitzroy {
  background-image: linear-gradient(to bottom, rgba(0,0,0,0.5) 0%,rgba(0,0,0,0.5) 100%),url("https://s3-us-west-2.amazonaws.com/s.cdpn.io/2522641/fitzroy.jpg");
  background-repeat: no-repeat;
  height: 300px;
  width: 300px;
  display: flex;
}

.fitzroy-header {
  text-align: center;
  margin-top: 60px;
  font-size: 25px;
  color: white;
}

.fitzroy-header-text {
  text-align: center;
  font-size: 15px;
  color: white;
}

.fitzroy-content {
  text-align: center;
  font-size: 10px;
  color: black;
  margin-top: 120px;
}

.kilda {
  background-image: linear-gradient(to bottom, rgba(0,0,0,0.5) 0%,rgba(0,0,0,0.5) 100%),url("https://s3-us-west-2.amazonaws.com/s.cdpn.io/2522641/st-kilda.jpg");
  background-repeat: no-repeat;
  height: 300px;
  width: 300px;
  display: flex;
}

.kilda-header {
  text-align: center;
  margin-top: 60px;
  font-size: 25px;
  color: white;
}

.kilda-header-text {
  text-align: center;
  font-size: 15px;
  color: white;
}

.kilda-content {
  text-align: center;
  font-size: 10px;
  color: black;
  margin-top: 120px;
}

.business {
  background-image: linear-gradient(to bottom, rgba(0,0,0,0.5) 0%,rgba(0,0,0,0.5) 100%),url("https://s3-us-west-2.amazonaws.com/s.cdpn.io/2522641/central-business-district.jpg");
  background-repeat: no-repeat;
  height: 300px;
  width: 300px;
  display: flex;
}

.business-header {
  text-align: center;
  margin-top: 60px;
  font-size: 25px;
  color: white;
}

.business-header-text {
  text-align: center;
  font-size: 15px;
  color: white;
}

.business-content {
  text-align: center;
  font-size: 10px;
  color: black;
  margin-top: 120px;
}
